# ⚽ Shotime FIFA World Cup 2026 Pool Tracker

A real-time pool tracker for you and your friends. Everyone joins with their name, makes group stage + bracket picks, and the live leaderboard updates as results come in.

---

## 🚀 Deploy in ~10 minutes

### Step 1 — Set up Firebase (free, ~3 min)

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add project** → name it `wc-pool-2026` → Continue
3. Disable Google Analytics (not needed) → **Create project**
4. In the left sidebar: **Build → Realtime Database**
5. Click **Create Database** → choose a location → Start in **test mode** → Enable
6. In the left sidebar: **Project Overview (gear icon) → Project settings**
7. Scroll to **Your apps** → click the **Web** icon (`</>`)
8. Register app name `wc-pool` → **Register app**
9. Copy the `firebaseConfig` object shown

### Step 2 — Paste your Firebase config

Open `src/firebase.js` and replace the placeholder values with your config:

```js
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "wc-pool-2026.firebaseapp.com",
  databaseURL: "https://wc-pool-2026-default-rtdb.firebaseio.com",
  projectId: "wc-pool-2026",
  storageBucket: "wc-pool-2026.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123",
};
```

> ⚠️ Make sure `databaseURL` is included — it's required for Realtime Database.

### Step 3 — Install & run locally (optional test)

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) to test.

### Step 4 — Deploy to Vercel (free, ~2 min)

1. Push this folder to a GitHub repo (or use Vercel CLI)
2. Go to [vercel.com](https://vercel.com) → **Add New Project**
3. Import your GitHub repo → click **Deploy**
4. Done! Vercel gives you a URL like `https://wc-pool-2026.vercel.app`

**Or deploy via CLI:**
```bash
npm install -g vercel
vercel
```

### Step 5 — Share the URL with your friends!

Text them the Vercel URL. Everyone can join, make picks, and see the live leaderboard from any device.

---

## 🔐 Admin Access

- Default password: `wc2026`
- To change it: open `src/data.js` and update `ADMIN_PASSWORD`
- The admin panel lets you enter actual results as the tournament plays — all scores update in real time for everyone

---

## 📊 Scoring System

| Pick | Points |
|------|--------|
| Correct group winner (1st) | 5 pts |
| Correct group runner-up (2nd) | 3 pts |
| Correct 3rd place | 2 pts |
| Round of 32 advancement | 5 pts |
| Quarterfinal advancement | 8 pts |
| Semifinal advancement | 12 pts |
| Finalist | 15 pts |
| Champion | 20 pts |

---

## 🛠️ Customization

- **Teams/Groups**: Edit `GROUPS` in `src/data.js` once the official 2026 draw is confirmed
- **Scoring**: Adjust `SCORING` in `src/data.js`
- **Admin password**: Change `ADMIN_PASSWORD` in `src/data.js`

---

Built with React + Vite + Firebase Realtime Database
